create function sequin_to_stacksync_transform() returns trigger
    language plpgsql
as
$$
DECLARE
    v_column_name TEXT;
    v_data_type TEXT;
    v_jsonb jsonb;
    v_str_value TEXT;
    v_num_value NUMERIC;
BEGIN
    v_jsonb := to_jsonb(NEW);

    FOR v_column_name, v_data_type IN
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_schema = TG_TABLE_SCHEMA
          AND table_name = TG_TABLE_NAME
          AND is_updatable = 'YES'
        LOOP
            CASE v_data_type
                WHEN 'ARRAY' THEN
                    IF (v_jsonb->v_column_name) IS NULL OR (v_jsonb->v_column_name)::text = 'null' THEN
                        v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], '[]');
                    ELSE
                        v_str_value := v_jsonb->v_column_name::text;
                        IF v_str_value LIKE '%email%' THEN
                            -- Extract email from JSON object in array (handles escaped quotes)
                            v_str_value := substring(v_str_value from '\\\"email\\\"\s*:\s*\\\"([^\\\"]+)\\\"');
                            IF v_str_value IS NOT NULL THEN
                                v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], to_jsonb(ARRAY[v_str_value]));
                            END IF;
                        ELSIF v_str_value LIKE '%specialValue%' OR v_str_value LIKE '%\"specialValue\"%' THEN
                            v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], '["NaN"]'::jsonb);
                        END IF;
                    END IF;

                WHEN 'boolean' THEN
                    IF (v_jsonb->v_column_name) IS NULL OR (v_jsonb->v_column_name)::text = 'null' THEN
                        v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], 'false');
                    END IF;

                WHEN 'numeric', 'decimal' THEN
                    v_str_value := v_jsonb->>v_column_name;
                    IF v_str_value IS NOT NULL AND v_str_value != '' THEN
                        v_num_value := TRUNC(v_str_value::numeric);
                        v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], to_jsonb(v_num_value));
                    END IF;

                WHEN 'double precision', 'real' THEN
                    v_str_value := v_jsonb->>v_column_name;
                    IF v_str_value IS NOT NULL AND v_str_value != '' THEN
                        v_num_value := FLOOR(v_str_value::numeric);
                        v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], to_jsonb(v_num_value));
                    END IF;

                WHEN 'text', 'character varying' THEN
                    v_str_value := v_jsonb->>v_column_name;
                    IF v_str_value LIKE '%#ERROR!%' THEN
                        v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], 'null');
                    ELSIF v_str_value LIKE '%''url'':%' THEN
                        v_str_value := substring(v_str_value from '''url''\s*:\s*''([^'']+)''');
                        IF v_str_value IS NOT NULL THEN
                            v_jsonb := jsonb_set(v_jsonb, ARRAY[v_column_name], to_jsonb(v_str_value));
                        END IF;
                    END IF;

                ELSE
                    NULL;
                END CASE;
        END LOOP;

    NEW := jsonb_populate_record(NEW, v_jsonb);
    RETURN NEW;
END;
$$;

alter function sequin_to_stacksync_transform() owner to postgres;

